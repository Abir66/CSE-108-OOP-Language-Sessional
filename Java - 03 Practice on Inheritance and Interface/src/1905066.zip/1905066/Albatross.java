public class Albatross extends Bird{
    public Albatross(String name, int age) {
        super(name, age);
    }

}
