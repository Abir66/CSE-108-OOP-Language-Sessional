public class GreatWhiteShark extends Fish {
    public GreatWhiteShark(String name, int age) {
        super(name,age);
    }
}
