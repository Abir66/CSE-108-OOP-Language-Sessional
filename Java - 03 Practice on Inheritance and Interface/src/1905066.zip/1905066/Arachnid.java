public class Arachnid extends Albatross {
    public Arachnid(String name, int age) {
        super(name, age);
    }
}
