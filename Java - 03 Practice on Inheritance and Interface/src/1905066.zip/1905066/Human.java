public class Human extends Mammal {
    public Human(String name, int age) {
        super(name, age);
    }

}
