public class FruitBat extends Mammal{
    public FruitBat(String name, int age) {
        super(name, age);
    }

}
