public class Animal{
    private String name;
    private int age;

    String bloodType;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }


    @Override
    public String toString(){
        return name + " is a " + getClass().getName() + ", aged " + age;

    }
}

